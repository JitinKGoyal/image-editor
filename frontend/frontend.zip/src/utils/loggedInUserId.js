export const loggedInUserId = JSON.parse(localStorage.getItem("my-image-editor"))?._id
