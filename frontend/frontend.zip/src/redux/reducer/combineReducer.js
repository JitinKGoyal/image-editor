import { combineReducers } from "redux";
import { myreducer as allStates } from "./reducer";

export default combineReducers({allStates})