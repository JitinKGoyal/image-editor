export default function dispatchFunction(data) {
    return {
        type: "a",
        payload: data
    }
}